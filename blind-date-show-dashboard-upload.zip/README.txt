BLIND DATE SHOW - DIRECT CLOUDFLARE UPLOAD

This edition is a single Cloudflare Worker script.
It does NOT use wrangler.toml, package.json, Node.js, or a build command.

In Cloudflare:
Workers & Pages -> Create -> Workers -> Upload files
Upload ONLY worker.js, then deploy.

The app uses Firebase for anonymous auth, Realtime Database, and WebRTC signaling.
Make sure Firebase Anonymous Authentication and Realtime Database are enabled.

No Cloudflare Durable Object is required for this edition.
